define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(kony.flex.DP);
            var flx = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "93.78%",
                "horizontalScrollIndicator": true,
                "id": "flx",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopyslFSbox0j45b341f53b744",
                "top": "43dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flx.setDefaultUnit(kony.flex.DP);
            var lstbx = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "lstbx",
                "isVisible": true,
                "left": "37dp",
                "masterData": [
                    ["lb1", "English"],
                    ["lb2", "Spanish"],
                    ["lb3", "French"]
                ],
                "onSelection": controller.AS_ListBox_b105ee406d3a4381865c6a3c4c2f4f17,
                "skin": "CopydefListBoxNormal0df706e15e18f41",
                "top": "35dp",
                "width": "300dp",
                "zIndex": 1,
                "enableHapticFeedback": true
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnGetLocale = new kony.ui.Button({
                "centerX": "49.61%",
                "centerY": "54.32%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnGetLocale",
                "isVisible": true,
                "left": "40dp",
                "onClick": controller.AS_Button_d1363a7fa80b41909745bc576d2631d7,
                "skin": "CopydefBtnNormal0a4012180ed8b46",
                "text": "Get Current Locale",
                "top": "200dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl1 = new kony.ui.Label({
                "height": "25.54%",
                "id": "lbl1",
                "isVisible": true,
                "left": "22dp",
                "skin": "CopydefLabel0be81bda9c5ec4f",
                "i18n_text": "kony.i18n.getLocalizedString(\"Hello\")",
                "textStyle": {},
                "top": "105dp",
                "width": "87.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var btnGetSupport = new kony.ui.Button({
                "centerX": "49.88%",
                "centerY": "63.43%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnGetSupport",
                "isVisible": true,
                "left": "40dp",
                "onClick": controller.AS_Button_f29c776e97d84421b4e6b94f70290fc7,
                "skin": "CopydefBtnNormal0jd047b63a3654c",
                "text": "Get Supported Locales",
                "top": "279dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeviceLocale = new kony.ui.Button({
                "centerX": "49.84%",
                "centerY": "72.46%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnDeviceLocale",
                "isVisible": true,
                "left": "40dp",
                "onClick": controller.AS_Button_c170289027ab431f986ed353c486bc30,
                "skin": "CopydefBtnNormal0ca86cf4358d948",
                "text": "Get Current Device Locale",
                "top": "357dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLocalizedString = new kony.ui.Button({
                "centerX": "49.91%",
                "centerY": "81.43%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnLocalizedString",
                "isVisible": true,
                "left": "40dp",
                "onClick": controller.AS_Button_c684187802ba4ac69d8547e3ee8df120,
                "skin": "CopydefBtnNormal0g6591cf5aa2045",
                "text": "Localized String",
                "top": "430dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnsetResource = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnsetResource",
                "isVisible": true,
                "left": "37dp",
                "onClick": controller.AS_Button_bff4786ad93045288a3c74e6471df785,
                "skin": "CopydefBtnNormal0a6c080e55d914e",
                "text": "Set Resource Bundle",
                "top": "580dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnsetDefaultLocale = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnsetDefaultLocale",
                "isVisible": true,
                "left": "37dp",
                "onClick": controller.AS_Button_i080f71bbac64174be45d184a2f6bd6a,
                "skin": "CopydefBtnNormal0cff23f9ddf4548",
                "text": "Set Default Locale",
                "top": "525dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnupdateResource = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnupdateResource",
                "isVisible": true,
                "left": "36dp",
                "onClick": controller.AS_Button_f00636745df740209d4531885316e178,
                "skin": "CopydefBtnNormal0cc132d2ffc6643",
                "text": "Update Resource Bundle",
                "top": "635dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteResource = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnDeleteResource",
                "isVisible": true,
                "left": "35dp",
                "onClick": controller.AS_Button_c197d0410bb54ca9b403fee8764fef8a,
                "skin": "CopydefBtnNormal0f5abe6dd837345",
                "text": "Delete Resource Bundle",
                "top": "690dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx.add(lstbx, btnGetLocale, lbl1, btnGetSupport, btnDeviceLocale, btnLocalizedString, btnsetResource, btnsetDefaultLocale, btnupdateResource, btnDeleteResource);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "43dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0i42319a41bad44",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var Label0c53ef5c83aa54e = new kony.ui.Label({
                "id": "Label0c53ef5c83aa54e",
                "isVisible": true,
                "left": "70dp",
                "skin": "CopydefLabel0b19cb0440fe944",
                "text": "Internationalization API",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxHeader.add(Label0c53ef5c83aa54e);
            this.add(flx, flxHeader);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});