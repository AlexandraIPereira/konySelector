define("userForm1Controller", {
    //Type your controller code here
    setlocaleListbox: function() {
        if (this.view.lstbx.selectedKey == "lb1") {
            kony.i18n.setCurrentLocaleAsync("en_GB", this.onsuccesscallback, this.onfailurecallback);
        } else if (this.view.lstbx.selectedKey == "lb2") {
            kony.i18n.setCurrentLocaleAsync("es_AR", this.onsuccesscallback, this.onfailurecallback);
        } else if (this.view.lstbx.selectedKey == "lb3") {
            kony.i18n.setCurrentLocaleAsync("fr_FR", this.onsuccesscallback, this.onfailurecallback);
        }
    },
    getCurrentLocale: function() {
        var currentLocales = kony.i18n.getCurrentLocale();
        alert("CurrentLocale :" + currentLocales);
    },
    getSupportedLocale: function() {
        var supportedLocales = kony.i18n.getSupportedLocales();
        alert("Supported Locales :" + JSON.stringify(supportedLocales));
    },
    getCurrentDeviceLocale: function() {
        var locale = kony.i18n.getCurrentDeviceLocale();
        alert("current device locale is " + locale);
    },
    getLocalizedString: function() {
        var currentLocale = kony.i18n.getLocalizedString("Hello");
        alert(" LocalizedString Method called :" + currentLocale);
    },
    setDefaultLocaleAsync: function() {
        kony.i18n.setDefaultLocaleAsync("fr_FR", this.onsuccesscallback, this.onfailurecallback);
    },
    Checkthelocale: function() {
        var a = this.view.txtbx.text;
        if (kony.i18n.isLocaleSupportedByDevice("a") === true) {
            alert("This locale is supported");
        } else {
            alert("This Locale is not supported");
        }
    },
    setResourceBundle: function() {
        kony.i18n.setResourceBundle({
            Hello: "Hallo Welt",
        }, "de_DE");
        kony.i18n.setCurrentLocaleAsync("de_DE", this.onsuccesscallback, this.onfailurecallback);
    },
    deleteResourceBundle: function() {
        kony.i18n.deleteResourceBundle("de_DE");
        alert(" Resources bundle has been deleted.");
    },
    updateResourceBundle: function() {
        kony.i18n.updateResourceBundle({
            Hello: "Hallo Leute",
        }, "de_DE");
        kony.i18n.setCurrentLocaleAsync("de_DE", this.onsuccesscallback1, this.onfailurecallback);
    },
    onsuccesscallback: function(oldLocaleName, newLocaleName) {
        if (newLocaleName == "en_GB") {
            alert("You have changed your locale to English");
        } else if (newLocaleName == "es_AR") {
            alert("You have changed your locale to Spanish");
        } else if (newLocaleName == "fr_FR") {
            alert("You have changed your locale to French");
        } else if (newLocaleName == "de_DE") {
            alert("You have set the resource bundle to German");
            this.view.lstbx.masterData.push(["lb4", "German"]);
            /*= [
        ["lb1", "English"],
        ["lb2", "Spanish"],
        ["lb3", "French"],
        ["lb4", "German"]
    ];*/
        }
    },
    onsuccesscallback1: function(oldLocaleName, newLocaleName) {
        if (newLocaleName == "de_DE") {
            alert("You have updated the German resource bundle");
        }
    },
    onfailurecallback: function() {
        alert("Please enter correct locale");
    }
});
define("Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onSelection defined for lstbx **/
    AS_ListBox_b105ee406d3a4381865c6a3c4c2f4f17: function AS_ListBox_b105ee406d3a4381865c6a3c4c2f4f17(eventobject) {
        var self = this;
        self.setlocaleListbox.call(this);
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    },
    /** onClick defined for btnGetLocale **/
    AS_Button_d1363a7fa80b41909745bc576d2631d7: function AS_Button_d1363a7fa80b41909745bc576d2631d7(eventobject) {
        var self = this;
        return self.getCurrentLocale.call(this);
    },
    /** onClick defined for btnGetSupport **/
    AS_Button_f29c776e97d84421b4e6b94f70290fc7: function AS_Button_f29c776e97d84421b4e6b94f70290fc7(eventobject) {
        var self = this;
        return self.getSupportedLocale.call(this);
    },
    /** onClick defined for btnDeviceLocale **/
    AS_Button_c170289027ab431f986ed353c486bc30: function AS_Button_c170289027ab431f986ed353c486bc30(eventobject) {
        var self = this;
        return self.getCurrentDeviceLocale.call(this);
    },
    /** onClick defined for btnLocalizedString **/
    AS_Button_c684187802ba4ac69d8547e3ee8df120: function AS_Button_c684187802ba4ac69d8547e3ee8df120(eventobject) {
        var self = this;
        return self.getLocalizedString.call(this);
    },
    /** onClick defined for btnsetResource **/
    AS_Button_bff4786ad93045288a3c74e6471df785: function AS_Button_bff4786ad93045288a3c74e6471df785(eventobject) {
        var self = this;
        self.setResourceBundle.call(this);
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    },
    /** onClick defined for btnsetDefaultLocale **/
    AS_Button_i080f71bbac64174be45d184a2f6bd6a: function AS_Button_i080f71bbac64174be45d184a2f6bd6a(eventobject) {
        var self = this;
        return self.setDefaultLocaleAsync.call(this);
    },
    /** onClick defined for btnupdateResource **/
    AS_Button_f00636745df740209d4531885316e178: function AS_Button_f00636745df740209d4531885316e178(eventobject) {
        var self = this;
        self.updateResourceBundle.call(this);
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    },
    /** onClick defined for btnDeleteResource **/
    AS_Button_c197d0410bb54ca9b403fee8764fef8a: function AS_Button_c197d0410bb54ca9b403fee8764fef8a(eventobject) {
        var self = this;
        self.deleteResourceBundle.call(this);
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
