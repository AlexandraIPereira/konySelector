define("userForm3Controller", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnlogin **/
    AS_Button_ca6dbd2dfeb248e687737834a409d65c: function AS_Button_ca6dbd2dfeb248e687737834a409d65c(eventobject) {
        var self = this;

        function SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_True() {}

        function INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Success(response) {
            if (self.view.defaultBrowserWidgetForOauth2) {
                self.view.remove(self.view.defaultBrowserWidgetForOauth2);
            }

            function SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_Callback() {
                SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Login Successful.",
                "alertHandler": SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
            var ntf = new kony.mvc.Navigation("Form1");
            ntf.navigate();
        }

        function INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Failure(error) {
            if (self.view.defaultBrowserWidgetForOauth2) {
                self.view.remove(self.view.defaultBrowserWidgetForOauth2);
            }

            function SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_Callback() {
                SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }

        function SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_True() {}
        if (login_inputparam == undefined) {
            var login_inputparam = {};
            var loginOption = {};
        }
        loginOption.isSSOEnabled = true;
        login_inputparam.loginOption = loginOption;
        login_inputparam["serviceID"] = "FacebookSample$login";
        login_inputparam["operation"] = "login";
        if (!self.view.defaultBrowserWidgetForOauth2) {
            self.view.add(new kony.ui.Browser({
                "id": "defaultBrowserWidgetForOauth2",
                "left": "0dp",
                "top": "0dp",
                "width": "100%",
                "height": "100%"
            }, {}, {}));
        }
        login_inputparam["browserWidget"] = self.view.defaultBrowserWidgetForOauth2;
        FacebookSample$login = mfidentityserviceinvoker("FacebookSample", login_inputparam, INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Success, INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Failure);
    }
});
define("Form3ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnlogin **/
    AS_Button_ca6dbd2dfeb248e687737834a409d65c: function AS_Button_ca6dbd2dfeb248e687737834a409d65c(eventobject) {
        var self = this;

        function SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_True() {}

        function INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Success(response) {
            if (self.view.defaultBrowserWidgetForOauth2) {
                self.view.remove(self.view.defaultBrowserWidgetForOauth2);
            }

            function SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_Callback() {
                SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Login Successful.",
                "alertHandler": SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
            var ntf = new kony.mvc.Navigation("Form1");
            ntf.navigate();
        }

        function INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Failure(error) {
            if (self.view.defaultBrowserWidgetForOauth2) {
                self.view.remove(self.view.defaultBrowserWidgetForOauth2);
            }

            function SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_Callback() {
                SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__d39721dabd3d45e6b648806a08ae3378_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }

        function SHOW_ALERT__c4f04189704047f2bdff0e8d6c246616_True() {}
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "FacebookSample$login";
        login_inputparam["operation"] = "login";
        if (!self.view.defaultBrowserWidgetForOauth2) {
            self.view.add(new kony.ui.Browser({
                "id": "defaultBrowserWidgetForOauth2",
                "left": "0dp",
                "top": "0dp",
                "width": "100%",
                "height": "100%"
            }, {}, {}));
        }
        login_inputparam["browserWidget"] = self.view.defaultBrowserWidgetForOauth2;
        FacebookSample$login = mfidentityserviceinvoker("FacebookSample", login_inputparam, INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Success, INVOKE_IDENTITY_SERVICE__b739de6b017340dfab79107179a3f8c2_Failure);
    }
});
define("Form3Controller", ["userForm3Controller", "Form3ControllerActions"], function() {
    var controller = require("userForm3Controller");
    var controllerActions = ["Form3ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
