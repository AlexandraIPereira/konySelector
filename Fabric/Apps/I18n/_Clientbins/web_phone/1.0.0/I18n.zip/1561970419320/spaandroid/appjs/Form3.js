define("Form3", function() {
    return function(controller) {
        function addWidgetsForm3() {
            this.setDefaultUnit(kony.flex.DP);
            var flexlogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "260dp",
                "id": "flexlogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flexlogin.setDefaultUnit(kony.flex.DP);
            var lblWelcomePleaseLogin = new kony.ui.Label({
                "bottom": "10dp",
                "centerX": "50%",
                "id": "lblWelcomePleaseLogin",
                "isVisible": true,
                "skin": "defDataPanelLabelWelcome",
                "text": "Welcome! Please Login",
                "top": "10dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var btnlogin = new kony.ui.Button({
                "bottom": "10dp",
                "centerX": "50.00%",
                "focusSkin": "defDataPanelBtnFocus",
                "height": "45dp",
                "id": "btnlogin",
                "isVisible": true,
                "onClick": controller.AS_Button_ca6dbd2dfeb248e687737834a409d65c,
                "skin": "defDataPanelBtnNormal",
                "text": "Login",
                "top": "50dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexlogin.add(lblWelcomePleaseLogin, btnlogin);
            this.add(flexlogin);
        };
        return [{
            "addWidgets": addWidgetsForm3,
            "enabledForIdleTimeout": false,
            "id": "Form3",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});